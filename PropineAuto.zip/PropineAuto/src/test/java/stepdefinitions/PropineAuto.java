package stepdefinitions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helper.LocatorRepo;
import helper.WebDriverHelper;
import io.cucumber.datatable.DataTable;

/**
 * This Class consists of the steps to execute from the Feature file
 * 
 * @author souvikghosh
 *
 */
public class PropineAuto {

	private static final Logger LOG = LoggerFactory.getLogger(PropineAuto.class);
	WebDriver driver = WebDriverHelper.initiateDriver();
	LocatorRepo locatorRepo = new LocatorRepo();
	WebDriverWait wait = new WebDriverWait(driver, 15);

	@Given("User Navigates to Home Page of Propine")
	public void user_Navigates_to_Home_Page_of_Propine() throws InterruptedException {
		WebDriverHelper.openURL(driver);
	}
	
	@Given("The url is correct")
	public void urlIsCorrect() {
		Assert.assertTrue(driver.getCurrentUrl().equalsIgnoreCase("https://vast-dawn-73245.herokuapp.com/"));
	}
	

	@When("The Propine logo is loaded")
	public void verifyPropineLogoIsPresent() {
		System.out.println("---The Propine Logo is present---");
		Assert.assertTrue(driver.findElements(locatorRepo.propineLogo).size() > 0);
	}

	@Then("The header and subheader displayed with correct content")
	public void headerAndSubHeader() throws InterruptedException {
		String innerText = null;
		if (driver.findElement(locatorRepo.headerOne).isDisplayed()) {
			innerText = driver.findElement(locatorRepo.headerOne).getText();
			Assert.assertTrue(innerText.contains("Propine Date Parser"));
		}

		if (driver.findElement(locatorRepo.subHeader).isDisplayed()) {
			innerText = driver.findElement(locatorRepo.subHeader).getText();
			Assert.assertTrue(innerText.contains("Enter a text in any format, press submit to interpret it as a date"));
		}
		driver.close();
	}

	@Then("The Date field, submit button and Result section are present")
	public void fieldsValidate() {
		Assert.assertTrue(driver.findElement(locatorRepo.dateField).isDisplayed());
		Assert.assertTrue(driver.findElement(locatorRepo.dateLabel).isDisplayed());
		Assert.assertTrue(driver.findElement(locatorRepo.submitButton).isDisplayed());
		Assert.assertTrue(driver.findElement(locatorRepo.resultLabel).isDisplayed());
		driver.close();
	}

	@And("^The date parsing is working properly$")
	public void enterValidDateAndSubmit(DataTable testData) throws InterruptedException {
		enterValidDateAndSubmitOrEnter(testData, "Submit");
	}
	
	
	@And("^The date parsing is working properly by clicking enter$")
	public void enterValidDateAndClickEnter(DataTable testData) throws InterruptedException {
		enterValidDateAndSubmitOrEnter(testData, "Enter");		
	}
	

	@When("The system should not allow alphabets - special chars and invalid date")
	public void invalidDateProcessing(DataTable testData) throws InterruptedException {
		List<String> list = new ArrayList<String>();

		/* Dynamic Date processing and Validation */
		List<String> details = testData.asList(String.class);
		for (String s : details) {
			list = processDate(s.trim());

			driver.findElement(locatorRepo.dateField).sendKeys(s);
			driver.findElement(locatorRepo.submitButton).click();
			try {
			    TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException ie) {
			    Thread.currentThread().interrupt();
			}
			for (int i = 1; i < list.size(); i++) 
			{
				Assert.assertTrue(driver.findElement(locatorRepo.parsedDateContainer).getText().contains("Invalid date"));
			}
			System.out.println("---The date field is not allowing alphabets and wrong date format---");
		}
		driver.close();
	}

	

	/**
	 * This method split the date input and make the list
	 * @param date
	 * @return
	 */
	public List<String> processDate(String date) {
		String delimeter = "";
		if (date.contains("/")) {
			delimeter = "/";
		} else if (date.contains("-")) {
			delimeter = "-";
		}

		String[] dateSplit = date.split(delimeter);

		List<String> compList = new ArrayList<String>();
		for (String s : dateSplit) {
			compList.add(s);
		}
		return compList;
	}
	
	
	
	/**
	 * This method is to Submit or Enter after entering date
	 * @param testData
	 * @param key
	 * @throws InterruptedException
	 */
	public void enterValidDateAndSubmitOrEnter(DataTable testData, String key) throws InterruptedException {
		List<String> list = new ArrayList<String>();

		/* Dynamic Date processing and Validation */
		List<String> details = testData.asList(String.class);
		for (String s : details) {
		 	list = processDate(s.trim());

			driver.findElement(locatorRepo.dateField).sendKeys(s);
			if(key.equalsIgnoreCase("Submit"))
			{
				driver.findElement(locatorRepo.submitButton).click();
			}
			else if(key.equalsIgnoreCase("Enter"))
			{
				Actions actions = new Actions(driver); 
				driver.findElement(locatorRepo.dateField).click();
				actions.sendKeys(Keys.ENTER).perform();
			}
				try {
			    TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException ie) {
			    Thread.currentThread().interrupt();
			}
			
			for (int i = 1; i < list.size(); i++) 
			{
				Assert.assertTrue(driver.findElement(locatorRepo.parsedDateContainer).getText().contains(list.get(i)));
				try {
				    TimeUnit.SECONDS.sleep(5);
				} catch (InterruptedException ie) {
				    Thread.currentThread().interrupt();
				}
			}
		}
		driver.close();
	}

}